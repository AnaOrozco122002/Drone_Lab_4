<?php
echo '
    
';


			           
?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Menú de gestion de ayudas</title>
         
        </head>
       <body>
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/portada.png" border=0 width=1300 height=300> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
     </table>
     
         <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
   
	  	   <tr valign="top">
             <td height="20%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Menu de Solicitud de Ayudas </h1></b></font>  
			  
		       </td>
             	    </tr>
              
		    </table>
     
        <table width="40%">
  	      <tr>
  	      <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">    
            
			        <a href="ver_centrales.php"><img src="img/botiquin.jpg" width="70%" height="70%" border=0></a>
          </th>
          <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

			        <a href="ver_suministros.php"><img src="img/rescate_2.png" width="70%" height="70%" border=0></a>
		  </th>
		  <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

		            <a href="ver_alertas.php">
                      <img src="img/comida.jpg" width="70%" height="70%" border="0">
                    </a>
          </th>
     
		  </tr>
        <tr>
				<td colspan=1 width="30%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=2 color="#4000B8"> <b>Implementos de Primeros Auxilios</b></font>  
				</td> 	
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=2 color="#4000B8"> <b>Implementos de Rescate</b></font>  
				</td>
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=2 color="#4000B8"> <b> Raciones de Alimentos</b></font>  
				</td>
      </tr>	
        </table>
        <hr>
        
         <form method=POST action="menu_rescatista.php">
 	     
       <tr>	
				  <td bgcolor="#EEEEEE" align=rigth colspan=2> 
				    <input type="hidden" name="volver" value="S1">  
				    <input type="submit" value="VOLVER" name="VOLVER">  
          </td>	
                    
	     </tr>
      </form>