<?php
include "conexion.php";
session_start();
if ($_SESSION["autenticado"] != "SIx3")
{
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
}
else
{ 
      
    
 $mysqli = new mysqli($host, $user, $pw, $db);
 $sqlusu = "SELECT * from tipo_usuario where id_usuario='2'";
 $resultusu = $mysqli->query($sqlusu);
 $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
 $desc_tipo_usuario = $rowusu[1];
 
 if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
 echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
 //header('Location:../../index.php?mensaje=4');
$id_usuario = $_SESSION["id_usuario"];
 
}
?>
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Ver Centrales </title>
         </title>
        </head>
       <body>
           <td valign="top" align=right>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Nombre Usuario</u>:   ".$_SESSION["nombre_usuario"];?> </b></font><br>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Tipo Usuario</u>:   ".$desc_tipo_usuario;?> </b></font><br>  
              <font FACE="arial" SIZE=2 color="#00FFFF"> <b><u> <a href="cerrar_sesion.php"> Cerrar Sesion </a></u></b></font>  

           </td>
	     </tr>
     </table> 
    
<?php

include "menu_administrados.php";

    
?>      
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
   
	  	   <tr valign="top">
             <td height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Ver Centrales </h1></b></font>  
			  
		       </td>
	     
            
	          <td height="20%" align="right" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
			  <img src="img/central_1.png" border=0 width=110 height=110>    
		       </td>
		     </tr>
		    </table>
            
            <table width="70%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
      

                <section class="Titulo 2">
                    <table align = "center">
                    <tr>
                    <td valign="top" align= width=60%>
                     <h1><font color=darkblue> Información y Mapa de ubicación de Centrales </font></h1>
             	    </td>
             	    </tr>
                    </table>
                </section>
              
		    </table>
          
                
            <?php
                   
                   $x=0;
                    //$id_ruta = array();
                    $mysqli = new mysqli($host, $user, $pw, $db);
                    
                    //$sqlIdV = "SELECT id_vehiculo, placa, id_ruta FROM vehiculos WHERE (id_empresa = $id_empresa) AND (estado = 1);";
                   
                    $sqlCen="SELECT * FROM centrales";
                    $resultCen = $mysqli->query($sqlCen);
                    
                    if ($resultCen==1){
                        //echo 'funcionó';
                    }

                    //if ($resultCen > 0) {
                        
                        while($rowCen = $resultCen->fetch_array(MYSQLI_NUM)){ 
                            
                                //$sqlDatos = "SELECT * FROM datos_f WHERE id_vehiculo = $rowIdV[0] order by id DESC LIMIT 1";
                                //$resultDatos = $mysqli->query($sqlDatos);
                                //$rowDatos = $resultDatos->fetch_array(MYSQLI_NUM);
                                
                                //echo 'obtenido: '.$rowDatos [1];
                                
                                $id_central[$x] = $rowCen[0];
                                $nombre[$x] = $rowCen[1];
                                $latitud[$x] = $rowCen[2];
                                $longitud[$x] = $rowCen[3];
                           
                               
                                 //echo "Id_central: $id_central[$x], nombre: $nombre[$x], Latitud: $latitud[$x], Longitud: $longitud[$x] <br>";
                                 $x++;
                        }
            ?>

                <div id="map" ></div>
               
                <script>
                  var map;
                     
            
                  // ALMACENA EN VARIABLES LA UBICACION INICIAL Y FINAL
                <?php $la= 2.44197231456874 ?>;
                <?php $lo=-76.60622344970703 ?>;
                
                  var la= <?php echo $la ?>;
                  var lo= <?php echo $lo ?>;
                  var uluru = {lat: la, lng: lo};
            
                  function initMap() {
                      var mapContainer = document.getElementById('map');
                        mapContainer.style.width = '700px'; // Ancho
                        mapContainer.style.height = '500px'; // Alto
                        mapContainer.style.margin = '0 auto'; // Centro

                    map = new google.maps.Map(document.getElementById('map'), {
                      zoom: 14,
                      center: uluru,
                      mapTypeId: 'roadmap'
                    });
                    

                
                      <?php
                    
                 
                        for ($k = 0; $k < $x; $k++) {
                          
                            $latit = $latitud[$k];
                            $longi = $longitud[$k];
                           
                    
                            if (!empty($latit) && !empty($longi)) {
                                ?>
                                var latit = <?php echo $latit; ?>;
                                var longi = <?php echo $longi; ?>;
                                var uru = {lat: latit, lng: longi};
                    
                          
                                var marker = new google.maps.Marker({
                                    position: uru,
                                    icon: "img/central_icon.png",
                                    map: map,
                                });
                    
                                var infoWindow = new google.maps.InfoWindow({
                                    content: " Id central: <?php echo $id_central[$k]; ?><br>"
                                        + " Nombre: <?php echo $nombre[$k]; ?> <br>"
                                });
                                
                                
                                infoWindow.open(map, marker);
                                <?php
                            }
                        }
                   // }
                    ?>
            
            }
            
                </script>
                <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDscKFOMV__hZHTvYyhREmH1_HKfkXF7Ys&callback=initMap">
                //src="https://maps.googleapis.com/maps/api/js?key=&callback=initMap">  <!-- Se deben reemplazar las XXXX por la API Key de Google MAPS -->
                </script>

            
        </body>
     </html>
              