<?php
include "conexion.php";
session_start();
if ($_SESSION["autenticado"] != "SIx3")
{
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
}
else
{ 
      
    
 $mysqli = new mysqli($host, $user, $pw, $db);
 $sqlusu = "SELECT * from tipo_usuario where id_usuario='3'";
 $resultusu = $mysqli->query($sqlusu);
 $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
 $desc_tipo_usuario = $rowusu[1];
 
 if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
 echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
 //header('Location:../../index.php?mensaje=4');
$id_usuario = $_SESSION["id_usuario"];
 
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title> INFORMACION SUMUNISTROS 
		  </title>
      <meta http-equiv="refresh" content="15" />
    </head>
    <body>
         
           <td valign="top" align=right>
            
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Nombre Usuario</u>:   ".$_SESSION["nombre_usuario"];?> </b></font><br>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Tipo Usuario</u>:   ".$desc_tipo_usuario;?> </b></font><br>  
              <font FACE="arial" SIZE=2 color="#00FFFF"> <b><u> <a href="index.php"> Cerrar Sesion </a></u></b></font>  

           </td> 
         
         
          <?php
 	        include "menu_empleado.php";
          ?>
          
          
         
          
       <?php
       
        //=============================
        
      if (isset($_GET["mensaje"]))
      {
        $mensaje = $_GET["mensaje"];
        if ($_GET["mensaje"]!=""){?>
      
  		     <tr>
             <td> </td>
             <td height="20%" align="left">
                  <table width=60% border=1>
                   <tr>
                    <?php 
                       if ($mensaje == 1)
                         echo "<td bgcolor=#DDFFDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >Suministro actualizado correctamente.";
                       if ($mensaje == 2)
                         echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >El Suministro no fue actualizado correctamente. Se presentó un inconveniente.";
                       if ($mensaje == 3)
                         echo "<td bgcolor=#DDFFDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >Suministro creado correctamente.";
                       if ($mensaje == 4)
                         echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >El suministro no fue creado. Se presentó un inconveniente";
                    
                    
                    
                       if ($mensaje == 5)
                         echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >Vehiculo no fue creado. Ya existe un Vehiculo con la misma identificación.";
                    if ($mensaje == 6)
                         echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >Ya existe un vehiculo con el mismo Id de tarjeta.";
                    if ($mensaje == 7)
                         echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                    style=color: #000000; font-weight: bold >El vehiculo no fue creado, ya existe un vehiculo con el mismo Id de tarjeta.";
                      ?>
                    </td>
                   </tr>
                  </table>
              </td>
    		     </tr>
           <?php
            }
           }   
           
                  //=============================
            ?> 
          
   
      <table width=95% align=center border=0>
           <tr>  
             <td align=right>
                  <form method=POST action="add_suministros.php">                   
 
                  <input style="background-color: #DBA926; font-size: 16px;" type=submit color= blue value="Agregar Suministro" name="Agregar suministro">
                  
                  </form> 
             </td>  
           </tr>
        </table>
          
  
          
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="#FFFFFF">
    	 <tr>
         <td valign="top" align=center width=80& colspan=8 bgcolor="white"">
          
         </td>
 	     </tr>
 	     <tr>
         <td valign="top" align=center width=80& colspan=8 bgcolor="darkblue"">
           <h1> <font color=white>Informacion de suministros disponibles</font></h1>
         </td>
 	     </tr>
    	 <tr>
          
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Id Suministro</b>
             </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Central</b>
         </td>
          <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Tipo</b>
         </td>
          <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Nombre</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Peso por unidad (gr)</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Cantidad Disponible</b>
         </td>
         <td valign="top" align=center bgcolor="#FFFFFF">
            <b> </b>
         </td>
 	     </tr>
 	     
 	     
 	     <?php

 	     
// la siguiente linea almacena en una variable denominada sql1, la consulta en lenguaje SQL que quiero realizar a la base de datos.
$sql1 = "SELECT * from suministros where id_suministro > 0 order by id_suministro ASC"; // Aqu� se ingresa el valor recibido a la base de datos.


$result1 = $mysqli->query($sql1);


$contador = 0;
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 
 $id_suministro = $row1[0];
 $tipo =$row1[1];
 $nombre =$row1[2];
 $peso =$row1[3];
 $cantidad_disp =$row1[4];
 $id_central =$row1[5];
 
 //consulta del nombre del suminsitro
 $sql2 = "SELECT nombre from tipo_suministro where id_tipo_sum=$tipo";
 $result2 = $mysqli->query($sql2);
 $row2=$result2->fetch_array(MYSQLI_NUM);
 $nombre_tipo =$row2[0];
 
 //consulta del nombre de la central
 
 $sql3 = "SELECT nombre from centrales where id_central=$id_central"; 
 $result3 = $mysqli->query($sql3);
 $row3=$result3->fetch_array(MYSQLI_NUM);
 $nombre_central =$row3[0];

 
 $contador++;
?>
    	 <tr>
         
         <td valign="top" align=center>
           <?php echo $id_suministro; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $nombre_central; ?> 
         </td>
           <td valign="top" align=center>
           <?php echo $nombre_tipo; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $nombre; ?> 
         </td> 
         <td valign="top" align=center>
           <?php echo $peso; ?> 
         </td>  
         <td valign="top" align=center>
           <?php echo $cantidad_disp; ?> 
         </td>  
        <td bgcolor="#FFFFFF" align=center> 
			  <font FACE="arial" SIZE=2 color="#000000"> <a href="mod_suministros.php?id_suministro=<?php echo $id_suministro; ?>"> <img src="img/mod.png" border=0 width=40 height=40></a></font>   
		</td>
 	     </tr>
<?php
}
?>
  
 	     
 	     
 	        </body>
   </html>
