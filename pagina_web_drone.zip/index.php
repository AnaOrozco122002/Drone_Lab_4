<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd>
  <html>
    <head>
      <title> Página de Drone
		  </title>
      <meta charset="utf-8">
      <meta http-equiv="refresh" content="15" />
    </head>
    <body>
      <table width="90%" align=center cellpadding=5 border=1 bgcolor="#FFFFFF">
    	 <tr>
         <td valign="top" align=center width=90%  bgcolor="7B01E8"">
           <img src="img/portada.png" width=1100 height=250>
         </td>
         <td valign="top" align=center width=40% bgcolor="7B01E8"">
           <h2> <font color=white>Ingreso de Usuarios </font></h2>
            <form method="POST" action="validar.php">
              <table width="100%" align=center border=0 bgcolor="7B01E8">
  	            <tr>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
         		       Usuario:
                  </td>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                     <input type=text value="" name="login1" required> 
              </td                </tr>  
  	            <tr>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                    Password:
                  </td>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                     <input type=password value="" name="passwd1" required> 
                  </td>
                </tr>  
  	            <tr>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                    &nbsp;&nbsp;
                  </td>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="7B01E8" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                   <input type=submit value="Enviar" name="Enviar"> 
                  </td>
                </tr>  
                <?php
            
                if (isset($_GET["mensaje"]))
                 {
                 $mensaje = $_GET["mensaje"];
                    if ($_GET["mensaje"]!=""){
                ?>
  	            <tr>
                  <td width="25%" height="20%" align="center" 				
                    bgcolor="#FFCCCC" class="_espacio_celdas_p" 					
                    style="color: #FF0000; 
			             font-weight: bold">
                    <u>Datos Incorrectos:</u>
                  </td>
                  <td width="25%" height="20%" align="left" 				
                    bgcolor="#FFDDDD" class="_espacio_celdas_p" 					
                    style="color: #FF0000; 
			             font-weight: bold">
                    <?php 
                       if ($mensaje == 1)
                         echo "El password del usuario no coincide.";
                       if ($mensaje == 2)
                         echo "No hay usuarios con el login (usuario) ingresado o está inactivo.";
                       if ($mensaje == 3)
                         echo "No se ha logueado en el Sistema. Por favor ingrese los datos.";
                       if ($mensaje == 4)
                         echo "Su tipo de usuario, no tiene las credenciales suficientes para ingresar a esta opción.";
                    ?>                         
                  </td>
                </tr> 
    
                <?php 
                   }
                 }
                 
                ?>
            
               </table>  
             </form> 
         </td>
 	     </tr>
 	     
    	 <tr>
         <td valign="top" align=left width=80& colspan=2 bgcolor="D4C0E5">
           <h2> <font color=black>Descripci&oacute;n del Sistema </font></h2>
           <p align=justify> <font color=#555555 size=3>
            El sistema busca la manera de contrarrestar el nivel de afectación que provocan diversas catástrofes naturales de alto nivel.
            Esto por medio de un sistema de drones que brinden suministros y/o elementos básicos como lo son medicamentos, alimentos o demás.
            Apoyando así a rescatistas y afectados mientras los entes como bomberos o policía logran acceder a la zona afectada para prestar la respectiva ayuda.

          </font></p>
          <br>
           <h2> <font color=black>Servicios </font></h2>
           <p align=justify> <font color=#555555 size=3>
            Entrega de elementos básicos en zonas de dificil acceso, como zonas rurales.
          </font></p>
          <br>
           <h2> <font color=black>Quienes Somos </font></h2>
           <p align=justify> <font color=#555555 size=3>
           
            Somos una empresa que se dedica a brindar un sistma de drones expecializados en la entrega de suministros básicos. Nuestros servicios se orientan a sistemas que trabajan en la gestión de riesgos como la 
            guardía civil, bomberos o cruz roja.
            
          </font></p>
         </td>
 	     </tr>
       </table>
     </body>
   </html>