<?php
include "conexion.php";
session_start();
if ($_SESSION["autenticado"] != "SIx3")
{
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
}
else
{ 
      
    
 $mysqli = new mysqli($host, $user, $pw, $db);
 $sqlusu = "SELECT * from tipo_usuario where id_usuario='1'";
 $resultusu = $mysqli->query($sqlusu);
 $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
 $desc_tipo_usuario = $rowusu[1];
 
 if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
 echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
 //header('Location:../../index.php?mensaje=4');
$id_usuario = $_SESSION["id_usuario"];
 
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
           <head>
        <body>
               <td valign="top" align=right>
            
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Nombre Usuario</u>:   ".$_SESSION["nombre_usuario"];?> </b></font><br>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Tipo Usuario</u>:   ".$desc_tipo_usuario;?> </b></font><br>  
              <font FACE="arial" SIZE=2 color="#00FFFF"> <b><u> <a href="index.php"> Cerrar Sesion </a></u></b></font>  

           </td> 
            <?php
                include "menu_rescatista.php";
              ?>
              
              
            <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=110%>
              <table width="100%" align=center border=0>
            	   <tr>
                
                  <td valign="top" align=center width=60%>
                     <h1><font color=darkblue>Reporta tu ubicación </font></h1>
             	    </td>
             	    
           	    </tr>
         	    </table>
           </td>
           <td valign="top" align=right>
             

                  </td>
	             </tr>
            </table>
                 <?php
                                
                  if (isset($_GET["mensaje"]))
                  {
                    $mensaje = $_GET["mensaje"];
                    if ($_GET["mensaje"]!=""){?>
                           
                            <tr>
                         <td> </td>
                         <td height="30%" align="center">
                              <table width=100% border=1>
                               <tr>
                                <?php 
                                   if ($mensaje == 1)
                                     echo "<td bgcolor=#DDFFDD class=_espacio_celdas_p 					
                                style=color: #000000; font-weight: bold; text-align: center; font-size: 16px; >Ubicación Almacenada correctamente.";

                                   if ($mensaje == 2)
                                     echo "<td bgcolor=#FFDDDD class=_espacio_celdas_p 					
                                style=color: #000000; font-weight: bold >Hubo un error al almacenar la ubicación, inténtelo nuevamente.";
                                  
                                  ?>
                                </td>
                                <br>
                               </tr>
                              </table>
                          </td>
                		     </tr>
                		     <?php
                        }
                     }   
   
                 ?>
          </body>     
          </head>
    <head>
        
    <meta charset="utf-8">
    <title>Permite mover un marcador en un mapa para obtener las coordenadas</title>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        width: 100%;
        height: 80%;
      }
      #coords {
        width: 500px;
      }
    </style>
    <body>            
    <div id="map"></div>
    
    <form method="POST" action="guardar_ubi.php">
      <b>Arrastre el marcador hasta la posición correcta en el mapa y presione enviar para guardar la ubicación.</b><br>
      <input type="text"  id="coords" value="<?php echo $coords; ?>" name=coordenada />
      <input type="submit" value="Enviar">
      
    </form>
    
    
    
    
    <script>
      var marker;          // Variable del marcador
      var coords = {};     // Coordenadas obtenidas con la geolocalización
      

      // Función principal
      function initMap() {
        // Usamos la API para geolocalizar el usuario
        
        if (navigator.geolocation) {
            
          navigator.geolocation.getCurrentPosition(
            function(position) {
              coords = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
              };
              setMapa(coords);  // Pasamos las coordenadas al método para crear el mapa
            },
            function(error) {
              console.log(error);
              coords = { lat: 2.4400000, lng: -76.6100000 };
              setMapa(coords);
            }
          );
        } else {
          coords = { lat: 2.4400000, lng: -76.6100000 };
         
          setMapa(coords);
        }
        
      }

      function setMapa(coords) {
        // Se crea una nueva instancia del objeto mapa
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: new google.maps.LatLng(coords.lat, coords.lng)
          
         
        });

        
        // Creamos el marcador en el mapa con sus propiedades
        // Para nuestro objetivo, tenemos que poner el atributo draggable en true
        // La posición serán las mismas coordenadas obtenidas en la geolocalización
        
        marker = new google.maps.Marker({
          map: map,
          draggable: true,
          animation: google.maps.Animation.DROP,
          position: new google.maps.LatLng(coords.lat, coords.lng)
        
       
            
        });
        
        
        
        // Agregamos un evento al marcador junto con la función de callback al igual que el evento dragend que indica cuando el usuario ha soltado el marcador
        marker.addListener('click', toggleBounce);

        marker.addListener('dragend', function(event) {
          // Escribimos las coordenadas de la posición actual del marcador dentro del input #coords
          document.getElementById("coords").value = this.getPosition().lat() + "," + this.getPosition().lng();
          <?php echo $coordenada;?>

        });
      }
      
      
      // Callback al hacer clic en el marcador. Lo que hace es quitar y poner la animación BOUNCE
      function toggleBounce() {
        if (marker.getAnimation() !== null) {
          marker.setAnimation(null);
        } else {
          marker.setAnimation(google.maps.Animation.BOUNCE);
        }
      }
    </script>
    <script async
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDscKFOMV__hZHTvYyhREmH1_HKfkXF7Ys&callback=initMap">
</script>
    <!-- Reemplaza 'API_KEY' por tu propia clave de API de Google Maps -->
  </body>
</html>