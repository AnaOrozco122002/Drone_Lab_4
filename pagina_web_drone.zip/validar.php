<?php
// PROGRAMA DE VALIDACION DE USUARIOS
$login = $_POST["login1"];
$passwd = $_POST["passwd1"];
echo $login;
session_start();
include ("conexion.php");
$mysqli = new mysqli($host, $user, $pw, $db);
$sql = "SELECT * from usuarios where nombre_usuario = '$login' and estado_usuario= 1";
$result1 = $mysqli->query($sql);
$row1 = $result1->fetch_array(MYSQLI_NUM);
$numero_filas = $result1->num_rows;
if ($numero_filas > 0)
  {
    $passwdc = $row1[6];
    if ($passwdc == $passwd)
      {
        $_SESSION["autenticado"]= "SIx3";
        $tipo_usuario = $row1[1];
        $nombre_usuario = $row1[5];
        $sql2 = "SELECT * from tipo_usuario where id_usuario='$tipo_usuario'";
        $result2 = $mysqli->query($sql2);
        $row2 = $result2->fetch_array(MYSQLI_NUM);
        $desc_tipo_usu = $row2[1];
        $_SESSION["tipo_usuario"]= $desc_tipo_usu;
        $_SESSION["nombre_usuario"]= $nombre_usuario;  
        if ($tipo_usuario == 1){
header("Location:elegir_ubi.php");
}
        elseif ($tipo_usuario == 2){
header("Location:menu_administrados.php");
}
elseif ($tipo_usuario == 3){
header("Location:menu_empleado.php");
}
      }
    else 
     {
header('Location:index.php?mensaje=1');
     }
  }
else
  {
header('Location:index.php?mensaje=2');
 }  
?>