<?php

$velocidad_max =20938;
$long_velocidad_max= strlen($velocidad_max);
for ($i=$long_velocidad_max;$i<2;$i++)
  {
    $velocidad_max = "0".$velocidad_max;//
  }


//echo $velocidad_max; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.

echo json_encode($velocidad_max);



?>
