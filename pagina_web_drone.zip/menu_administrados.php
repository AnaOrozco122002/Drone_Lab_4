<?php
echo '
    
';


			           
?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Menu Administrador</title>
         
        </head>
       <body>
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/portada.png" border=0 width=1300 height=300> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
     </table>
     
         <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
   
	  	   <tr valign="top">
             <td height="20%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Menú Administrador </h1></b></font>  
			  
		       </td>
             	    </tr>
              
		    </table>
     
        <table width="40%">
  	      <tr>
  	      <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">    
            
			        <a href="ver_centrales.php"><img src="img/central_1.png" width="70%" height="70%" border=0></a>
          </th>
          <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

			        <a href="ver_suministros.php"><img src="img/inventario.jpg" width="70%" height="70%" border=0></a>
		  </th>
		  <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

		            <a href="ver_alertas.php">
                      <img src="img/dron_paquete.jpg" width="70%" height="70%" border="0">
                    </a>
          </th>
          <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

			        <a href="ver_pedidos.php"><img src="img/pedido.jpg" width="70%" height="70%" border=0></a>
		  </th>
     
		  </tr>
        <tr>
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=3 color="#4000B8"> <b>Ver Centrales</b></font>  
				</td> 	
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=3 color="#4000B8"> <b>Ver Inventario</b></font>  
				</td>
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=3 color="#4000B8"> <b> Monitoreo de Drone</b></font>  
				</td>
				<td colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF"> 
				  <font FACE="arial" SIZE=3 color="#4000B8"> <b> Ver pedidos</b></font>  
				</td>
      </tr>	
        </table>
        <hr>
        
         <form method=POST action="index.php">
 	     
       <tr>	
				  <td bgcolor="#EEEEEE" align=rigth colspan=2> 
				    <input type="hidden" name="volver" value="S1">  
				    <input type="submit" value="VOLVER" name="VOLVER">  
          </td>	
                    
	     </tr>
      </form>