<?php
include "conexion.php";
session_start();
if ($_SESSION["autenticado"] != "SIx3")
{
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
}
else
{ 
      
    
 $mysqli = new mysqli($host, $user, $pw, $db);
 $sqlusu = "SELECT * from tipo_usuario where id_usuario='2'";
 $resultusu = $mysqli->query($sqlusu);
 $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
 $desc_tipo_usuario = $rowusu[1];
 
 if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
 echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
 //header('Location:../../index.php?mensaje=4');
$id_usuario = $_SESSION["id_usuario"];
 
}
?>
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Ver Pedidos </title>
         
        </head>
       <body>
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                    
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
           <td valign="top" align=right>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Nombre Usuario</u>:   ".$_SESSION["nombre_usuario"];?> </b></font><br>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Tipo Usuario</u>:   ".$desc_tipo_usuario;?> </b></font><br>  
              <font FACE="arial" SIZE=2 color="#00FFFF"> <b><u> <a href="cerrar_sesion.php"> Cerrar Sesion </a></u></b></font>  

           </td>
	     </tr>
     </table>
    
<?php

include "menu_administrados.php";

    
?>      
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
   
	  	   <tr valign="top">
             <td height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Ver Pedidos </h1></b></font>  
			  
		       </td>
	     
            
	          <td height="20%" align="right" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
			  <img src="img/pedido.jpg" border=0 width=120 height=120>    
		       </td>
		     </tr>
		    </table>
            
            
            
            
            
            <table width="70%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
      

                <section class="Titulo 2">
                    <table align = "center">
                    <tr>
                    <td valign="top" align= width=60%>
                     <h1><font color=darkblue> Información de Pedidos </font></h1>
             	    </td>
             	    </tr>
                    </table>
                </section>
                
            </table>
                
            <table width="100%" align=center cellpadding=11 border=3 bgcolor="#FFFFFF">
                
                <tr>
                  
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Id pedido</b>
                     </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Usuario</b>
                     </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Estado pedido</b>
                 </td>
                  <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Latitud</b>
                 </td>
                  <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Longitud</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Elemento 1</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Cantidad E1</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Elemento 2</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Cantidad E2</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Elemento 3</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Cantidad E3</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Peso total (gr)</b>
                 </td>
                 <td valign="top" align=center bgcolor="darkblue" style="color: white;">
                    <b>Cantidad drones necesario</b>
                 </td>
         	     </tr>
 	     

        <?php
        
            
            $mysqli = new mysqli($host, $user, $pw, $db);
      
            $sql1 = "SELECT * from pedidos order by id_pedido ASC"; 
            
  
            $result1 = $mysqli->query($sql1);
            
            
            $contador = 0;
            while($row1 = $result1->fetch_array(MYSQLI_NUM))
            {
             
             $usuario =$row1[0];
             $id_pedido = $row1[1];
             $estado_pedido =$row1[2];
             $elem_1 =$row1[3];
             $cant_1 =$row1[4];
             $elem_2 =$row1[5];
             $cant_2 =$row1[6];
             $elem_3 =$row1[7];
             $cant_3 =$row1[8];
             $latitud =$row1[9];
             $longitud =$row1[10];
             $peso_total=$row1[11];
             $Ndrones =$row1[12];
             
             
             //consulta del nombre del estado del pedido
             $sql2 = "SELECT estado_p from estado_pedido where id=$estado_pedido";
             $result2 = $mysqli->query($sql2);
             $row2=$result2->fetch_array(MYSQLI_NUM);
             $nombre_estado =$row2[0];
             
             
             //consulta del nombre usuario
             $sql3 = "SELECT nombre_usuario from usuarios where id_usuario=$usuario";
             $result3 = $mysqli->query($sql3);
             $row3=$result3->fetch_array(MYSQLI_NUM);
             $nombre_usuario =$row3[0];
             
             
             //consulta nombre elementos
             
             $sqlE1 = "SELECT nombre from suministros where id_suministro=$elem_1"; 
             $resultE1 = $mysqli->query($sqlE1);
             $rowE1=$resultE1->fetch_array(MYSQLI_NUM);
             $nombre_E1 =$rowE1[0];
             
             $sqlE2 = "SELECT nombre from suministros where id_suministro=$elem_2"; 
             $resultE2 = $mysqli->query($sqlE2);
             $rowE2=$resultE2->fetch_array(MYSQLI_NUM);
             $nombre_E2 =$rowE2[0];
             
             $sqlE3 = "SELECT nombre from suministros where id_suministro=$elem_3"; 
             $resultE3 = $mysqli->query($sqlE3);
             $rowE3=$resultE3->fetch_array(MYSQLI_NUM);
             $nombre_E3 =$rowE3[0];
            
             
             $contador++;
            ?>
                	 <tr>
                     
                     <td valign="top" align=center>
                       <?php echo $id_pedido; ?> 
                     </td>
                     <td valign="top" align=center>
                       <?php echo $nombre_usuario; ?> 
                     </td>
                     <td valign="top" align=center>
                       <?php echo $nombre_estado; ?> 
                     </td>
                       <td valign="top" align=center>
                       <?php echo $latitud; ?> 
                     </td>
                     <td valign="top" align=center>
                       <?php echo $longitud; ?> 
                     </td> 
                     <td valign="top" align=center>
                       <?php echo $nombre_E1; ?> 
                     </td>  
                     <td valign="top" align=center>
                       <?php echo $cant_1; ?> 
                     </td>  
                      <td valign="top" align=center>
                       <?php echo $nombre_E2; ?> 
                     </td>  
                     <td valign="top" align=center>
                       <?php echo $cant_2; ?> 
                     </td>
                      <td valign="top" align=center>
                       <?php echo $nombre_E3; ?> 
                     </td>  
                     <td valign="top" align=center>
                       <?php echo $cant_3; ?> 
                     </td>
                     <td valign="top" align=center>
                       <?php echo $peso_total; ?> 
                     </td>
                      <td valign="top" align=center>
                       <?php echo $Ndrones; ?> 
                     </td>
             	     </tr>
        <?php
        }
        ?>
          
          
          </table>
          
          <table width="70%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
      

                <section class="Titulo 2">
                    <table align = "center">
                    <tr>
                    <td valign="top" align= width=60%>
                     <h1><font color=darkblue> Mapa de ubicación de Pedidos </font></h1>
             	    </td>
             	    </tr>
                    </table>
                </section>
                
            </table>
          
                
            <?php
                   
                    $x=0;
                    $nombre_estado = array();
             
                    $mysqli = new mysqli($host, $user, $pw, $db);
                   
                    $sqlP="SELECT * FROM pedidos";
                    $resultP = $mysqli->query($sqlP);
                        
                        while($rowP = $resultP->fetch_array(MYSQLI_NUM)){ 
                            
                                $id_usuario=$id_usuarioV[$x] = $rowP[0];
                                $id_pedidoV[$x] = $rowP[1];
                                $estado=$estadoV[$x] = $rowP[2];
                                $latitudV[$x] = $rowP[9];
                                $longitudV[$x] = $rowP[10];

                                
                                $sqlE="SELECT estado_p FROM estado_pedido where id = $estado";
                                $resultE = $mysqli->query($sqlE);
                                $rowE=$resultE->fetch_array(MYSQLI_NUM);
                                $valor=$rowE[0];
                                $nombre_estado[] = $valor;
                                
                                
                                $sqlU = "SELECT nombre_usuario from usuarios where id_usuario=$id_usuario";
                                $resultU = $mysqli->query($sqlU);
                                $rowU=$resultU->fetch_array(MYSQLI_NUM);
                                $valor2=$rowU[0];
                                $n_usuario[] = $valor2;
                                
                               
                                //echo "Id_pedido: $id_pedidoV[$x], estado: $estadoV[$x], Latitud: $latitudV[$x], Longitud: $longitudV[$x] <br>";
                                $x++;
                        }
                    
                    $sqlCen="SELECT * FROM centrales";
                    $resultCen = $mysqli->query($sqlCen);
                        
                        while($rowCen = $resultCen->fetch_array(MYSQLI_NUM)){ 
 
                                $id_central[$x] = $rowCen[0];
                                $nombreC[$x] = $rowCen[1];
                                $latitudC[$x] = $rowCen[2];
                                $longitudC[$x] = $rowCen[3];
                          
                               
                                 //echo "Id_central: $id_central[$x], nombre: $nombre[$x], Latitud: $latitud[$x], Longitud: $longitud[$x] <br>";
                                 $x++;
                        }
            ?>

                <div id="map" ></div>
               
                <script>
                  var map;
                     
            
                  // ALMACENA EN VARIABLES LA UBICACION INICIAL Y FINAL
                <?php $la= 2.44197231456874 ?>;
                <?php $lo=-76.60622344970703 ?>;
                
                  var la= <?php echo $la ?>;
                  var lo= <?php echo $lo ?>;
                  var uluru = {lat: la, lng: lo};
            
                  function initMap() {
                      var mapContainer = document.getElementById('map');
                        mapContainer.style.width = '700px'; // Ancho
                        mapContainer.style.height = '500px'; // Alto
                        mapContainer.style.margin = '0 auto'; // Centro

                    map = new google.maps.Map(document.getElementById('map'), {
                      zoom: 14,
                      center: uluru,
                      mapTypeId: 'roadmap'
                    });
                    

                
                      <?php
                    
                 
                        for ($k = 0; $k < $x; $k++) {
                          
                            $latit = $latitudV[$k];
                            $longi = $longitudV[$k];
                           
                    
                            if (!empty($latit) && !empty($longi)) {
                                ?>
                                var latit = <?php echo $latit; ?>;
                                var longi = <?php echo $longi; ?>;
                                var uru = {lat: latit, lng: longi};
                    
                          
                                var marker = new google.maps.Marker({
                                    position: uru,
                                    icon: "img/sos.png",
                                    map: map,
                                });
                    
                                var infoWindow = new google.maps.InfoWindow({
                                    content: " Id Pedido: <?php echo $id_pedidoV[$k]; ?><br>"
                                        + " Estado: <?php echo $nombre_estado[$k]; ?> <br>"
                                        + " Usuario: <?php echo $n_usuario[$k]; ?> <br>"
                                });
                                
                                
                                infoWindow.open(map, marker);
                                <?php
                            }
                        }
                        
                        
                         for ($k = 0; $k < $x; $k++) {
                          
                            $latit = $latitudC[$k];
                            $longi = $longitudC[$k];
                           
                    
                            if (!empty($latit) && !empty($longi)) {
                                ?>
                                var latit = <?php echo $latit; ?>;
                                var longi = <?php echo $longi; ?>;
                                var uru = {lat: latit, lng: longi};
                    
                          
                                var marker = new google.maps.Marker({
                                    position: uru,
                                    icon: "img/central_icon.png",
                                    map: map,
                                });
                    
                                var infoWindow = new google.maps.InfoWindow({
                                    content: " Id central: <?php echo $id_central[$k]; ?><br>"
                                        + " Nombre: <?php echo $nombreC[$k]; ?> <br>"
                                });
                                
                                
                                infoWindow.open(map, marker);
                                <?php
                            }
                        }
                        
                        
                   // }
                    ?>
            
            }
            
                </script>
                <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDscKFOMV__hZHTvYyhREmH1_HKfkXF7Ys&callback=initMap">
                </script>

            
        </body>
     </html>
              