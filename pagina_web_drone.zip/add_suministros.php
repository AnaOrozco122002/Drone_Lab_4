<?php
// PROGRAMA DE MENU ADMINISTRADORES
include "conexion.php";
include "menu_empleado.php";

/*session_start();
if ($_SESSION["autenticado"] != "SIx3")
    {
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
//header('Location:../../index.php?mensaje=3');
    }
else
    {      
        $mysqli = new mysqli($host, $user, $pw, $db);
  	    $sqlusu = "SELECT * from tipo_usuario where id='2'"; //CONSULTA EL TIPO DE USUARIO CON ID=2, UAE
        $resultusu = $mysqli->query($sqlusu);
        $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
  	    $desc_tipo_usuario = $rowusu[1];
        if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
//header('Location:../../index.php?mensaje=4');


 $id_empresa = $_SESSION["id_empresa"];
 

    }*/
    
    
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
          <link rel="stylesheet" href="css/estilos_virtual.css" 			type="text/css">
           <title> Gesti&oacute;n Suministros Mod</title>
        </head>
       <body>
        <table width="80%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	  
<?php


         
          $mysqli = new mysqli($host, $user, $pw, $db);
          
if ((isset($_POST["enviado"])))
  {

        
      //$id_suministro = $_POST["id_suministro"];
      $tipo =$_POST["tipo"];
      $nombre =$_POST["nombre"];
      $peso =$_POST["peso"];
      $cantidad_disp =$_POST["cantidad_disp"];
      $id_central =$_POST["id_central"];
     
        
        $sqlUP = "INSERT INTO suministros(tipo, nombre, peso_unidad, cantidad_disp, id_central) VALUES ('$tipo', '$nombre', '$peso', '$cantidad_disp', '$id_central')";
        echo $sqlUP;
        
        echo "===================";
        
        $resultUP = $mysqli->query($sqlUP);
        //$result1 = $mysqli->query($sql1);
        
        echo "======================";
        echo 'result: '.$resultUP;
        if ($resultUP == 1){
    
             echo "<script>window.location.href = 'http://bustrackerlabiii.tech/ver_suministros_empleado.php?mensaje=3';</script>";
        }else{
            echo "no funciona";
       
             echo "<script>window.location.href = 'http://bustrackerlabiii.tech/ver_suministros_empleado.php?mensaje=4';</script>"; 
        }
   

}
else
{

   ?>
	   <tr valign="top">
                <td width="50%" height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
			    <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Agregar Sumunistros </h1></b></font>
		       </td>
		      
	      
	    </tr>

   	     <tr>
                  <td colspan=2 width="25%" height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                      

                <form method=POST action="add_suministros.php">
                    
                <table width=50% border=1 align=center>
                       
                    <tr>	
				<td bgcolor="#D1E8FF" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Central</b></font>  
				</td>	
			
			
				<td bgcolor="#EEEEEE" align=center> 
				<select name=id_central required onchange="handleSelectionChange(this)">
		
				    <option value=" "> <?php echo " "; ?></option> 
				    <?php
                        
                        $sql3 = "SELECT * from centrales";
                        $result3 = $mysqli->query($sql3);
                        
                        
                        
                        while($row3 = $result3->fetch_array(MYSQLI_NUM)){
                            if($row3[0]!=0){

                      ?>
                                <option value="<?php echo $row3[0]; ?>"><?php echo $row3[1]; ?></option>
                        
                      <?php
                            }
                        }
                        
                        $result3->data_seek(0);
                      
                      ?>
                     
                  </select>
				</td>
	            </tr>       
                       
                       
                       
                <tr>	
				<td bgcolor="#D1E8FF" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Tipo de Suministro</b></font>  
				</td>	
			
				<td bgcolor="#EEEEEE" align=center> 
				<select name=tipo required onchange="handleSelectionChange(this)">
				    
				    <option value=" "> <?php echo " "; ?></option> 
			
				    
				    <?php
                        
                        $sql2 = "SELECT * from tipo_suministro";
                        $result2 = $mysqli->query($sql2);
                        
                        
                        while($row2 = $result2->fetch_array(MYSQLI_NUM)){
                            if($row2[0]!=0){

                      ?>
                                <option value="<?php echo $row2[0]; ?>"><?php echo $row2[1]; ?></option>
                        
                      <?php
                            }
                        }
                        
                        $result2->data_seek(0);
                      
                      ?>
                     
                  </select>
				</td>
	            </tr>
	            
	   
			    <tr>	
				<td bgcolor="#D1E8FF" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Nombre Suministro</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" name=nombre value=" " required>  
				</td>	
	            </tr>
			     
			     <tr>
				<td bgcolor="#D1E8FF" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Peso por unidad (gr)</b></font>  
				</td> 	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" name=peso value=" " required>  
				</td>	
			     </tr>
			  
                <tr>
				<td bgcolor="#D1E8FF" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Cantidad Disponible</b></font>  
				</td> 	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" name=cantidad_disp value=" " required>  
				</td>	
			     </tr>

             </table>
             
         </br>
         <input type="hidden" value="S" name="enviado">
         <input type="hidden" value="<?php echo $id_suministro; ?>" name="id_suministro"> 
       
         <table width=50% align=center border=0>
           <tr>  
             <td width=50%></td>                                                                       
             <td align=center><input style="background-color: #DBA926" type=submit color= blue value="Guardar" name="Guardar">
        </form> 
             </td>  
             
             <td align=left>
                  <form method=POST action="">                   
                  <input style="background-color: #EEEEEE" type=submit color= blue value="Volver" name="Volver">              
                  </form> 
             </td>  
           </tr>
        </table>
        </form>
                 
<br><br><hr>
                  </td>
                </tr>  

<?php
 }
?>

        </table>
       </body>
      </html>


   