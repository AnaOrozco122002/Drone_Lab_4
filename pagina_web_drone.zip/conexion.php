<?php





$host = "localhost";

$user = "u493725423_drone";

$pw = "Drone123*";

$db = "u493725423_drone";

?>
