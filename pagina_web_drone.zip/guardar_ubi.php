<?php
//session_start(); // Iniciar la sesión si no se ha hecho previamente
include("conexion.php"); // Conexión tiene la información sobre la conexión de la base de datos.
$mysqli = new mysqli($host, $user, $pw, $db); // Aquí se hace la conexión a la base de datos.
$sql1="SELECT * FROM ubicacion_pedidos ORDER by id desc limit 1";
$result1=$mysqli->query($sql1);
$row1=$result1->fetch_array(MYSQLI_NUM);

$coordenada1=$row1[1];
$coordenada2=$row1[2];

//$coordenada="NADA por ahora";
echo $coordenada1;
echo $coordenada2;


  
if (isset($_POST["coordenada"])) {
  $coordenada = $_POST["coordenada"]; // Toma el valor de la coordenada.
 
 // echo $coordenada;
  
  
  // Se separan en dos variables, latitud y longitud, para poder ingresarlas a la tabla ubicaciones de la base de datos.
  $ubicacion_coma = strpos($coordenada, ",");
  $latitud = substr($coordenada, 0, $ubicacion_coma);
  $longitud = substr($coordenada, $ubicacion_coma + 1);
  
    echo $latitud;
  
    //echo $latitud;
    //echo $longitud;
  // Obtener el nombre del usuario desde la sesión
  //$nombre_usuario = isset($_SESSION["nombre_usuario"]) ? $_SESSION["nombre_usuario"] : "";

  //if (!empty($nombre_usuario)) {
    $sql = "INSERT INTO ubicacion_pedidos (latitud, longitud) VALUES ('$latitud', '$longitud')";
    $resultado = $mysqli->query($sql);

    if ($resultado) {
      //echo "<script>window.location.href = 'https://bustrackerlabiii.tech/elegir_ubi.php?mensaje=1';</script>";
      echo "<script>window.location.href = 'https://bustrackerlabiii.tech/Menu_Ayuda2.php?coordenada=$coordenada';</script>";
      echo $coordenada;
      
    } else {
      echo "<script>window.location.href = 'https://bustrackerlabiii.tech/elegir_ubi.php?mensaje=2';</script>";
    }
  //} else {
    //header('HTTP/1.1 500 Internal Server Error');
    //echo "Error al obtener el nombre de usuario.";
  //}
} else {
  header('HTTP/1.1 500 Internal Server Error');
  //echo "Error al registrar la ubicación.";
}
  //echo "<script>window.location.href = 'https://bustrackerlabiii.tech/elegir_ubi.php';</script>";
?>