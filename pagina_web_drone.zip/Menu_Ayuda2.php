<?php
include "conexion.php";

session_start();

if ($_SESSION["autenticado"] != "SIx3")
{
echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php';</script>";
}
else
{ 
      
    
 $mysqli = new mysqli($host, $user, $pw, $db);
 $sqlusu = "SELECT * from tipo_usuario where id_usuario='1'";
 $resultusu = $mysqli->query($sqlusu);
 $rowusu = $resultusu->fetch_array(MYSQLI_NUM);
 $desc_tipo_usuario = $rowusu[1];
 
 if ($_SESSION["tipo_usuario"] != $desc_tipo_usuario)
 echo "<script>window.location.href = 'http://bustrackerlabiii.tech/index.php?mensaje=4';</script>";
 //header('Location:../../index.php?mensaje=4');

 $nombre=$_SESSION["nombre_usuario"];
 
 $sqlID = "SELECT id_usuario from usuarios where nombre_usuario='$nombre'";
 $resultID = $mysqli->query($sqlID);
 $rowID = $resultID->fetch_array(MYSQLI_NUM);
 $id_usuario = $rowID[0];

 
}
?>
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Solicitud de Ayudas</title>
           
        </head>
       <body>
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
           </td>
           <td valign="top" align=right>
            
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Nombre Usuario</u>:   ".$_SESSION["nombre_usuario"];?> </b></font><br>
              <font FACE="arial" SIZE=2 color="#000000"> <b><u><?php  echo "Tipo Usuario</u>:   ".$desc_tipo_usuario;?> </b></font><br>  
              <font FACE="arial" SIZE=2 color="#00FFFF"> <b><u> <a href="index.php"> Cerrar Sesion </a></u></b></font>  

           </td>
	     </tr>
     </table>
     
    <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">


     
<?php
include "menu_rescatista.php";
#$latitud = $_GET["latitud"];
#$longitud = $_GET["longitud"];
#echo $latitud;
$coordenada = $_GET["coordenada"]; // Toma el valor de la coordenada.
//echo $coordenada;
  // Se separan en dos variables, latitud y longitud, para poder ingresarlas a la tabla ubicaciones de la base de datos.
    $ubicacion_coma = strpos($coordenada, ",");
    $latitud = substr($coordenada, 0, $ubicacion_coma);
    $longitud = substr($coordenada, $ubicacion_coma+1);
    //echo $longitud;


if ((isset($_POST["enviado_2"])))
   {
   $enviado = $_POST["enviado_2"];
   if ($enviado == "S2")
        {
        
        

        $latitud = $_POST["latitud"];
        $longitud =  $_POST["longitud"];
        //echo $latitud;
        //echo $longitud;
        $ne_pri=$_POST["primeros_aux"];
        $sep_pri=explode(",", $ne_pri);
        $peso_pri=$sep_pri[0];
        $ne_elem=$_POST["elementos_Resc"];
        $sep_elem=explode(",", $ne_elem);
        $peso_elem=$sep_elem[0];
        $ne_al=$_POST["aliment"];
        $sep_al=explode(",", $ne_al);
        $peso_al=$sep_al[0];
        $primeros_aux = $sep_pri[1];
        $cantidad_primeros = $_POST["cantidad_primeros"];
        $elementos_Resc = $sep_elem[1];
        $cantidad_elem = $_POST["cantidad_elem"];
        $aliment = $sep_al[1];
        $cantidad_al = $_POST["cantidad_al"];
        
        $mysqli = new mysqli($host, $user, $pw, $db);
       
        $peso_total=($peso_pri*$cantidad_primeros)+($peso_al*$cantidad_al)+($peso_elem*$cantidad_elem);
        $num_drones=ceil($peso_total/1500);
        
        /*echo $peso_pri;
        echo ",";
        echo $peso_al;
        echo ",";
        echo $peso_elem;*/
        $sqlcon = "INSERT INTO `pedidos`(`id_usuario`, `estado_pedido`, `elem_1`, `cant_elem1`, `elem_2`, `cant_elem2`, `elem_3`, `cant_elem3`, `latitud`, `longitud`, `peso_total`, `num_drone`) VALUES (' $id_usuario','0','$primeros_aux','$cantidad_primeros','$elementos_Resc','$cantidad_elem','$aliment','$cantidad_al','$latitud','$longitud','$peso_total','$num_drones')";
        //echo $sqlcon;
        $resultcon = $mysqli->query($sqlcon);
        //echo $resultcon;
        //echo "datos enviados con éxito";
        
        ?>
            <td bgcolor="#2D007B" align=center> 
            <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Primeros Auxilios:</b></font> 
            </td>
         <?php
        
        
        }
     echo "<script>window.location.href = 'https://bustrackerlabiii.tech/elegir_ubi.php';</script>";   
   }
   
?>  

     
 <form method=POST action="Menu_Ayuda2.php">
 <table width=50% border=1 align=center>
 <tr> 
    <td bgcolor="#2D007B" align=center> 
    <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Primeros Auxilios:</b></font> 
    </td> 
    <td bgcolor="#EEEEEE" align=center colspan=2>
        <select name=primeros_aux required onchange="handleSelectionChange(this)">
                <?php 
                 $a = 0;
                 $sqlId= "SELECT * from suministros WHERE tipo=1 order by nombre ASC;"; 
                 $resultId = $mysqli->query($sqlId);
                 ?>
                     <option value="<?php echo 0; ?>"> <?php echo "No Aplica"; ?></option>
                 <?php
                 while($rowIdSm= $resultId->fetch_array(MYSQLI_NUM))
                 {
                    if($rowIdSm[0]!=0){
                        $IdTarj[$a] = $rowIdSm[0];
                        $nombre_suministro = $rowIdSm[2];
                        echo "Id: $IdTarj[$a]<br>";
                        $peso_pri=$rowIdSm[3];
                        $val= "$peso_pri";
                        $val .=",";
                        $val .= "$IdTarj[$a]";
                     ?> 
                     <option value="<?php echo $val; ?>"> <?php echo $nombre_suministro; ?></option> 
                        <?php
                        $a++;
                    }
                 }
                 $resultId->data_seek(0);
                ?>  
        </select>
        <td bgcolor="#2D007B" align=center> 
        <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Cantidad:</b></font> 
    </td> 
    <td bgcolor="#EEEEEE" align=center colspan=2>
                <select name=cantidad_primeros required onchange="handleSelectionChange(this)">
                            <option value="<?php echo 0; ?>"> <?php echo "0"; ?></option>
                            <option value="<?php echo 1; ?>"> <?php echo "1"; ?></option>
                            <option value="<?php echo 2; ?>"> <?php echo "2"; ?></option>
                            <option value="<?php echo 3; ?>"> <?php echo "3"; ?></option>
                            <option value="<?php echo 4; ?>"> <?php echo "4"; ?></option>
                </select>
    </td> 
 </tr>
 <tr> 
 <td bgcolor="#2D007B" align=center> 
 <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Implementos de Rescate: </b></font> 
 </td> 
<td bgcolor="#EEEEEE" align=center colspan=2>
            <select name=elementos_Resc required onchange="handleSelectionChange(this)">
                    <?php 
                     $b = 0;
                     $sqlelem= "SELECT * from suministros WHERE tipo=2 order by nombre ASC;"; 
                     $resultelem = $mysqli->query($sqlelem);
                     ?>
                        <option value="<?php echo 0; ?>"> <?php echo "No Aplica"; ?></option>
                     <?php
                     while($rowelem= $resultelem->fetch_array(MYSQLI_NUM))
                     {
                        if($rowelem[0]!=0){
                            $Idsum[$b] = $rowelem[0];
                            $nombre_elem = $rowelem[2];
                            $peso_elem=$rowelem[3];
                            $val_elem= "$peso_elem";
                            $val_elem .=",";
                            $val_elem .= "$Idsum[$b]";
                         ?> 
                         <option value="<?php echo $val_elem; ?>"> <?php echo $nombre_elem; ?></option> 
                            <?php
                            $b++;
                        }
                     }
                     $resultId->data_seek(0);
                    ?>  
            </select>
            <td bgcolor="#2D007B" align=center> 
            <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Cantidad:</b></font> 
    </td> 
<td bgcolor="#EEEEEE" align=center colspan=2>
            <select name=cantidad_elem required onchange="handleSelectionChange(this)">
                        <option value="<?php echo 0; ?>"> <?php echo "0"; ?></option>
                        <option value="<?php echo 1; ?>"> <?php echo "1"; ?></option>
                        <option value="<?php echo 2; ?>"> <?php echo "2"; ?></option>
                        <option value="<?php echo 3; ?>"> <?php echo "3"; ?></option>
                        <option value="<?php echo 4; ?>"> <?php echo "4"; ?></option>
                     
            </select>
    </td> 
 </tr>
 <tr> 
 <td bgcolor="#2D007B" align=center> 
 <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Alimentos: </b></font> 
 </td> 
<td bgcolor="#EEEEEE" align=center colspan=2>
            <select name=aliment required onchange="handleSelectionChange(this)">
                    <?php 
                     $c = 0;
                     $sqlal= "SELECT * from suministros WHERE tipo=3 order by nombre ASC;"; 
                     $resultal = $mysqli->query($sqlal);
                     ?>
                        <option value="<?php echo 0; ?>"> <?php echo "No Aplica"; ?></option>
                     <?php
                     while($rowal= $resultal->fetch_array(MYSQLI_NUM))
                     {
                        if($rowal[0]!=0){
                            $Idal[$c] = $rowal[0];
                            $nombre_al = $rowal[2];
                            $peso_al=$rowal[3];
                            $val_al= "$peso_al";
                            $val_al .=",";
                            $val_al .= "$Idal[$c]";
                         ?> 
                         <option value="<?php echo $val_al; ?>"> <?php echo $nombre_al; ?></option> 
                            <?php
                            $c++;
                        }
                     }
                     $resultId->data_seek(0);
                    ?>  
            </select>
            <td bgcolor="#2D007B" align=center> 
            <font FACE="arial" SIZE=2 color="#FFFFFF"> <b>Cantidad:</b></font> 
            
    </td> 
<td bgcolor="#EEEEEE" align=center colspan=2>
            <select name=cantidad_al required onchange="handleSelectionChange(this)">
                        <option value="<?php echo 0; ?>"> <?php echo "0"; ?></option>
                        <option value="<?php echo 1; ?>"> <?php echo "1"; ?></option>
                        <option value="<?php echo 2; ?>"> <?php echo "2"; ?></option>
                        <option value="<?php echo 3; ?>"> <?php echo "3"; ?></option>
                        <option value="<?php echo 4; ?>"> <?php echo "4"; ?></option>
                     
            </select>
    </td> 
 </tr>
</form> 
 <table width=50% align=center border=0>
 <tr> 
 <td width=50%></td> 
 <td align=center>
     <input style="background-color: #DBA926" type="hidden" name="enviado_2" value="S2"> 
     <input type="hidden" value="<?php echo $latitud; ?>" name="latitud">
     <input type="hidden" value="<?php echo $longitud; ?>" name="longitud">
     <input type="hidden" value="<?php echo $peso_pri; ?>" name="peso_pri">
     <input type="hidden" value="<?php echo $peso_al; ?>" name="peso_al">
     <input type="hidden" value="<?php echo $peso_elem; ?>" name="peso_elem">
     <input style="background-color: #DBA926" type=submit color= blue value="Grabar" name="Grabar">
 </td> 
 <td align=left>
 <form method=POST action="elegir_ubi.php"> 
 <input style="background-color: #EEEEEE" type=submit color= blue value="Volver" name="Volver"> 
 </form> 
 </td> 
 </tr>
 
 </table>
 </form> 
<br><br><hr>
 </td>
 </tr> 
 </table>
</body>
</html>




